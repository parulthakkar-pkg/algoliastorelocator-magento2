<?php
/**
 * Copyright © 2021 Neosoft Technologies. All rights reserved.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Algolia_Storelocator',
    __DIR__
);
